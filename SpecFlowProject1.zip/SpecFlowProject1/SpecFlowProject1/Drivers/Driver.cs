using System;

namespace SpecFlowProject1.Drivers
{
    public class Driver
    {
        //add code for managing drivers
    }
}