﻿using NUnit.Framework;

namespace SpecFlowProject1.Steps;

[Binding]
public sealed class CalculatorStepDefinitions
{
    // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

    private readonly ScenarioContext _scenarioContext;
    private static IWebDriver _driver = null;

    public CalculatorStepDefinitions(ScenarioContext scenarioContext)
    {
        _scenarioContext = scenarioContext;
    }

    [StepDefinition("I open (.*) browser")]
    public void IOpenBrowser(string browser)
    {
        switch (browser)
        {
            case "chrome":
                // open chrome Note: need to add the drivermanager to match the browser version and the driver version
                _driver = new ChromeDriver();
                break;
            case "firefox":
                // open firefox
                break;
            default:
                // open chrome
                break;
        }
    }

    [StepDefinition("I navigate to (.*)")]
    public void INavigateTo(string url)
    {
        _driver.Navigate().GoToUrl(url);
        // add code to wait for page to load
    }

    [StepDefinition("I enter (.*) in the (.*) field")]
    public void IEnterInTheField(string text, string iD)
    {
        // add code to wait for element to be visible
        _driver.FindElement(By.Id(iD)).SendKeys(text);
    }
    
    [StepDefinition("I click on (.*) button")]
    public void IClickOnButton(string iD)
    {
        // add code to wait for element to be visible
        _driver.FindElement(By.Id(iD)).click;
    }
    
    [StepDefinition("I am on (.*)")]
    public void IClickOnButton(string url)
    {
        // wait for page to load
    }
    
    //specific step definition to the sorting feature
    [StepDefinition("I select (.*) from the sorting dropdown menu")]
    public void ISelectFromTheSortingDropdown(string value)
    {
        var xpath = "//*[@id="header_container"]/div[2]/div[2]/span/select";
        var sortingdropdown = _driver.FindElement(By.xpath(xpath));
        var selectElement = new SelectElement(sortingdropdown);
        selectElement.SelectByValue(value); 
    }

    [StepDefinition("I see the text (.*) in the first item name")]
    public void ISeeTheTextInTheFirstItemName(string text)
    {
        var xpath = "//*[@id="inventory_container"]/div/div[1]";
        var element = _driver.FindElement(By.xpath(xpath));
        Assert.Contains(text, element.Text());
    }


}